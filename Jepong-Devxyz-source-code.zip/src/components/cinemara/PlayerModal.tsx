"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowLeft } from "lucide-react";
import type { Title } from "@/lib/cinemara/data";
import { trailerEmbed } from "@/lib/cinemara/art";
import { recordWatch } from "@/lib/cinemara/store";
import { fetchTitleInfo, getCachedInfo, setCachedInfo } from "@/lib/cinemara/enrich";

interface Props {
  title: Title;
  episode?: number;
  profileId: string | null;
  onBack: () => void;
}

/**
 * Full-screen watch view — plays the title's official trailer via
 * YouTube's embed (licensed source). Progress is seeded into
 * Continue Watching, mirroring the original's watch flow.
 */
export default function WatchView({ title: initial, episode, profileId, onBack }: Props) {
  const seeded = useRef(false);
  const [title, setTitle] = useState<Title>(initial);
  const [prevInitial, setPrevInitial] = useState<Title>(initial);
  if (prevInitial !== initial) {
    setPrevInitial(initial);
    setTitle(initial);
  }

  // enrich when the trailer key is missing (light titles)
  const needsTrailer = !initial.trailerKey;
  useEffect(() => {
    if (!needsTrailer) return;
    const cached = getCachedInfo(initial.id);
    if (cached?.trailerKey) {
      Promise.resolve().then(() => setTitle((t) => ({ ...t, ...cached })));
      return;
    }
    const [type, numId] = initial.id.split("-");
    let alive = true;
    fetchTitleInfo(type as "movie" | "tv", Number(numId))
      .then((info) => {
        setCachedInfo(initial.id, info);
        if (alive) setTitle((t) => ({ ...t, ...info }));
      })
      .catch(() => {});
    return () => {
      alive = false;
    };
  }, [needsTrailer, initial]);

  useEffect(() => {
    if (seeded.current) return;
    seeded.current = true;
    const progress = 18 + Math.floor(Math.random() * 40);
    recordWatch(profileId, title.id, progress, episode);
  }, [profileId, title.id, episode]);

  const label = episode ? `S1:E${episode}` : title.type === "series" ? "S1:E1" : "Feature";
  const embed = title.trailerKey
    ? trailerEmbed(title.trailerKey, { autoplay: true, mute: false, controls: true })
    : "";

  return (
    <div
      className="fixed inset-0 z-[60] bg-black"
      role="dialog"
      aria-modal="true"
      aria-label={`Playing ${title.title}`}
      style={{
        backgroundImage:
          "radial-gradient(80% 60% at 20% 10%, #0d2226 0%, #06141a 40%, #02070a 100%)",
      }}
    >
      {embed ? (
        <iframe
          src={embed}
          title={`${title.title} player`}
          allow="autoplay; encrypted-media; fullscreen"
          allowFullScreen
          className="absolute inset-0 h-full w-full"
        />
      ) : (
        <div className="flex h-full w-full flex-col items-center justify-center gap-3 text-center">
          <p className="text-2xl font-bold text-white">{title.title}</p>
          <p className="text-sm text-neutral-400">No trailer available for this title yet.</p>
        </div>
      )}

      <div className="pointer-events-none absolute inset-x-0 top-0 flex items-center gap-4 bg-gradient-to-b from-black/80 to-transparent px-5 py-5">
        <button
          onClick={onBack}
          aria-label="Go back"
          className="pointer-events-auto flex h-11 w-11 items-center justify-center rounded-full bg-black/60 text-white transition-colors hover:bg-black/80"
        >
          <ArrowLeft className="h-6 w-6" />
        </button>
        <span className="pointer-events-auto rounded bg-black/50 px-3 py-1 text-xs text-neutral-300">
          {title.title} · {label} · Official trailer playback
        </span>
      </div>
    </div>
  );
}
